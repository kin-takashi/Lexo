# Ô PHỦ GÓI CÂU HỎI MỚI (dev dn15-dn34) lên bộ đo đã giải nén từ lexo_eval_colab.zip
# Chạy MỘT lần, SAU khi đã giải nén lexo_eval_colab.zip và TRƯỚC khi tách / chấm.
# Chỉ thay 4 file: eval/bo_cau_hoi.json, eval/tach_ly_tuong_dev.json, scripts/danh_gia_nhieu.py, src/index/bo_cau_hoi.py
import glob, hashlib, os, shutil, zipfile

MARK = "LEXO_CAU_HOI_MOI.md"
GOC = None   # nếu ô tự tìm sai, điền tay thư mục dự án (có scripts/danh_gia_nhieu.py), ví dụ "/kaggle/working/lexo"

def sha256(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()

# 1) thư mục dự án (nơi đã giải nén lexo_eval_colab.zip)
if GOC is None:
    for p in ("/kaggle/working/lexo", "/content/lexo"):
        if os.path.exists(p + "/scripts/danh_gia_nhieu.py"):
            GOC = p
            break
if GOC is None:
    ds = [p for p in glob.glob("/kaggle/working/*/scripts/danh_gia_nhieu.py")]
    if len(ds) == 1:
        GOC = os.path.dirname(os.path.dirname(ds[0]))
assert GOC and os.path.exists(GOC + "/scripts/danh_gia_nhieu.py"), "Không thấy thư mục dự án: giải nén lexo_eval_colab.zip trước, hoặc điền GOC bằng tay"

# 2) gói câu hỏi mới: thư mục đã tự giải nén (Kaggle) hoặc file zip
tim = glob.glob("/kaggle/input/**/" + MARK, recursive=True) + glob.glob("/content/lexo_cau_hoi_moi*/**/" + MARK, recursive=True)
if tim:
    NGUON = os.path.dirname(sorted(tim)[0])
else:
    zs = glob.glob("/kaggle/input/**/lexo_cau_hoi_moi.zip", recursive=True) + glob.glob("/content/drive/MyDrive/lexo/lexo_cau_hoi_moi.zip")
    assert zs, "Không thấy gói lexo_cau_hoi_moi (thư mục hay zip). Kaggle: thêm dataset vào notebook; Colab: để zip trong MyDrive/lexo/"
    tam = "/kaggle/working/_cau_hoi_moi" if os.path.exists("/kaggle/working") else "/content/_cau_hoi_moi"
    shutil.rmtree(tam, ignore_errors=True)
    zipfile.ZipFile(zs[0]).extractall(tam)
    NGUON = os.path.dirname(sorted(glob.glob(tam + "/**/" + MARK, recursive=True))[0])

# 3) kiểm hash nguồn → chép → kiểm hash đích
dong = [l.split(None, 1) for l in open(NGUON + "/SHA256SUMS", encoding="utf-8").read().splitlines() if l.strip()]
assert len(dong) == 4, f"SHA256SUMS phải có đúng 4 dòng, có {len(dong)}"
for h, rel in dong:
    rel = rel.strip().lstrip("*")
    assert sha256(f"{NGUON}/{rel}") == h, f"Hash nguồn sai: {rel} (tải lên lỗi?)"
for h, rel in dong:
    rel = rel.strip().lstrip("*")
    shutil.copy2(f"{NGUON}/{rel}", f"{GOC}/{rel}")
    assert sha256(f"{GOC}/{rel}") == h, f"Hash đích sai: {rel}"
    print("đã phủ", rel, h[:12])

# 4) đếm lại
import json
bo = json.load(open(GOC + "/eval/bo_cau_hoi.json", encoding="utf-8"))["cau_hoi"]
dn = [c for c in bo if c["tap"] == "dev" and c["loai"] == "nhieu_dieu"]
print(f"dev nhiều Điều: {len(dn)} tình huống, {sum(len(c['dieu']) for c in dn)} Điều đáp án (phải là 34 và 74); tổng {len(bo)} câu (phải là 370)")
assert (len(dn), sum(len(c['dieu']) for c in dn), len(bo)) == (34, 74, 370), "Số đếm sai"
print("GOC =", GOC)
print("LƯU Ý: các file dự đoán cũ eval/tach_dev_*.json chỉ phủ 14 tình huống đầu; tách lại trên cả 34 tình huống trước khi chấm.")
