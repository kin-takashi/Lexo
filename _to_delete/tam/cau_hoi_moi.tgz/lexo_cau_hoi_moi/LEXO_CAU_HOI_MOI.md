# Lexo — gói câu hỏi mới của tập dev (dn15–dn34)

Gói NHỎ phủ lên bộ đo `lexo_eval_colab.zip`. Chỉ thay 4 file, không đổi gì khác (đã so từng file với gói cũ: ngoài 4 file này mọi file đều giống hệt).

| File | Thay đổi |
|---|---|
| `eval/bo_cau_hoi.json` | 350 → 370 câu; dev nhiều Điều 14 → 34 tình huống (74 Điều đáp án), thêm dn15–dn34 |
| `eval/tach_ly_tuong_dev.json` | thêm hành vi tách tay cho dn15–dn34 (mốc «tách lý tưởng»), nay đủ 34 tình huống |
| `scripts/danh_gia_nhieu.py` | thêm `--chi-id` (ví dụ `--chi-id dn01-dn14` hoặc `dn15-dn34`) để báo cáo riêng từng nhóm |
| `src/index/bo_cau_hoi.py` | thêm hàm `loc_theo_id` cho `--chi-id` |

## Cách dùng

**Kaggle:** tạo dataset mới từ file zip này (Kaggle tự giải nén), thêm dataset vào notebook, giải nén `lexo_eval_colab.zip` như thường lệ, rồi chạy MỘT ô: dán nguyên nội dung `o_phu_len_kaggle.py`. Ô tự tìm gói (thư mục hoặc zip) bằng cách tìm file `LEXO_CAU_HOI_MOI.md`, kiểm SHA256, chép đè 4 file, kiểm lại, và dừng nếu số đếm không phải 34 tình huống / 74 Điều / 370 câu.

**Colab:** để `lexo_cau_hoi_moi.zip` cạnh `lexo_eval_colab.zip` trong `MyDrive/lexo/`, chạy cùng ô trên sau ô giải nén.

Sau khi phủ: chạy `python scripts/danh_gia_nhieu.py --tap dev --chi-tiet` (34 tình huống) và hai báo cáo con `--chi-id dn01-dn14`, `--chi-id dn15-dn34`. File dự đoán tách cũ (`eval/tach_dev_*.json`) chỉ có 14 tình huống đầu: phải tách lại trên đủ 34 tình huống.

## CẤM

- Gói này chứa chữ của mọi câu hỏi đo, kể cả tập kiểm tra đóng băng (qn01–qn26). **Không bao giờ** đưa vào notebook học, không dùng để soạn dữ liệu học hay chọn tham số theo từng câu.
- dn15–dn34 do Claude soạn, nhãn còn `nhap` (chờ người dùng duyệt). Dùng để chẩn đoán và so sánh mô hình, chưa phải số báo cáo cuối.

## Kiểm tra toàn vẹn

`SHA256SUMS` (4 dòng) nằm cùng thư mục với file này: `sha256sum -c SHA256SUMS`.
