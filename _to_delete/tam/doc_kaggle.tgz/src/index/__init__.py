"""embedding, FTS, vector"""
